package crux;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import crux.Token.Kind;
import crux.parsing.LL1Reader;

public class Compiler 
{
	public static final String uciNetID = "dtetreau";
	public static final String studentID = "35571095";
	public static final String studentName = "Drake Tetreault";
	
	/* NOTE: main() method removed because AutoTester will be used. */
}