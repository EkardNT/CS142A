package ast;

public interface Expression extends Visitable {
	public int getLeftmostCharPos();
}
